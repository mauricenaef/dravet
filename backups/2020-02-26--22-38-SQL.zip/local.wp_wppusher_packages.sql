/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_wppusher_packages` VALUES
(4,"dravet.2019","mauricenaef/dravet","master",2,1,1,"gh",0,"dist/themes/dravet.2019");
