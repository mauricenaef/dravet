/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_wc_tax_rate_classes` VALUES
(1,"Reduced rate","reduced-rate"),
(2,"Zero rate","zero-rate"),
(3,"Ermässigter Steuersatz","ermaessigter-steuersatz"),
(4,"Steuerfrei","steuerfrei"),
(5,"Reduzierter Preis","reduzierter-preis"),
(6,"0 Preis","0-preis"),
(7,"Steuerfreie","steuerfreie");
