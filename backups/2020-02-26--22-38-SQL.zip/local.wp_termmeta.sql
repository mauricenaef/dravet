/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_termmeta` VALUES
(1,30,"product_count_product_cat","0"),
(2,40,"order","0"),
(3,42,"order","0"),
(4,40,"product_count_product_cat","8"),
(5,42,"product_count_product_cat","5");
