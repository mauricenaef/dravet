/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_comments` VALUES
(57,589,"ActionScheduler","","","","2020-02-07 08:13:41","2020-02-07 08:13:41","Aktion abgeschlossen",0,"1","ActionScheduler","action_log",0,0),
(58,590,"ActionScheduler","","","","2020-02-07 08:13:41","2020-02-07 08:13:41","Aktion gestartet",0,"1","ActionScheduler","action_log",0,0),
(59,590,"ActionScheduler","","","","2020-02-07 08:13:41","2020-02-07 08:13:41","Aktion abgeschlossen",0,"1","ActionScheduler","action_log",0,0),
(60,591,"ActionScheduler","","","","2020-02-07 08:13:41","2020-02-07 08:13:41","Aktion gestartet",0,"1","ActionScheduler","action_log",0,0),
(61,591,"ActionScheduler","","","","2020-02-07 08:13:41","2020-02-07 08:13:41","Aktion abgeschlossen",0,"1","ActionScheduler","action_log",0,0),
(56,589,"ActionScheduler","","","","2020-02-07 08:13:41","2020-02-07 08:13:41","Aktion gestartet",0,"1","ActionScheduler","action_log",0,0),
(53,589,"ActionScheduler","","","","2020-02-07 08:12:47","2020-02-07 08:12:47","Aktion erstellt",0,"1","ActionScheduler","action_log",0,0),
(54,590,"ActionScheduler","","","","2020-02-07 08:12:47","2020-02-07 08:12:47","Aktion erstellt",0,"1","ActionScheduler","action_log",0,0),
(55,591,"ActionScheduler","","","","2020-02-07 08:12:47","2020-02-07 08:12:47","Aktion erstellt",0,"1","ActionScheduler","action_log",0,0);
