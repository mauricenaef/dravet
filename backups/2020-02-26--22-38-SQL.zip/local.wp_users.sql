/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_users` VALUES
(1,"maurice","$P$BE5giROXuA093iWTsljSNQ0ER3.1pa0","maurice","me@mauricenaef.ch","","2019-02-24 23:19:06","",0,"maurice"),
(2,"ines.neeracher@dravet.ch","$P$BJr9Xg4v3f.fc2HrmtVq0m42alE/ov/","ines-neeracherdravet-ch","ines.neeracher@dravet.ch","","2019-02-25 09:20:11","",0,"Ines Neeracher"),
(3,"renata.heusser@dravet.ch","$P$BENG.vamXF/CyvmRkW82m4eoHeWN3./","renata-heusserdravet-ch","renata.heusser@dravet.ch","","2019-02-25 09:20:46","",0,"Renata Heusser"),
(4,"reto.conrad@dravet.ch","$P$B5m.rgVcRRwpu0PXm0jxP2f58pgpRW0","reto-conraddravet-ch","reto.conrad@dravet.ch","","2019-02-25 09:21:21","",0,"Reto Conrad");
